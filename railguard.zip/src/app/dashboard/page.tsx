import React from 'react'
import { DashboardView } from '@/modules/dashboard/ui/views/dashboard-views'
const page = () => {
  return (
    <div>
        <DashboardView />
    </div>
  )
}

export default page