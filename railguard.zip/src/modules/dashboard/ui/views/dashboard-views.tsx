import React from 'react'

export const DashboardView = () => {
  return (
    <div>DashboardView</div>
  )
}
